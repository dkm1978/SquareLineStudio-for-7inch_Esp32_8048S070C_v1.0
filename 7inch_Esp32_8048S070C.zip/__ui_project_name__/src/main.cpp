#include "7inch_board.h"

void setup()
{
    BoardInit(true,50);
    Serial.printf("Redzen %d",xPortGetCoreID());
}

void loop()
{ 
  lv_timer_handler();
  delay(5);
}
