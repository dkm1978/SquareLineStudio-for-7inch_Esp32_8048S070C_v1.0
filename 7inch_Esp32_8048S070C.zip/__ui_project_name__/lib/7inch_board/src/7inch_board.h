#ifndef _ARDUINO_GFX_LIBRARIES_H_
#define _ARDUINO_GFX_LIBRARIES_H_
#include "Arduino.h"
#include "Arduino_DataBus.h"
#include "databus/Arduino_ESP32RGBPanel.h"
#include "display/Arduino_RPi_DPI_RGBPanel.h"
#include "Arduino_GFX.h"
#include <lvgl.h>
#include <ui.h>
//#include "font/u8g2.h"


#if !defined(LITTLE_FOOT_PRINT)
#include "canvas/Arduino_Canvas.h"
#include "canvas/Arduino_Canvas_Indexed.h"
#include "canvas/Arduino_Canvas_3bit.h"
#include "canvas/Arduino_Canvas_Mono.h"
#endif // !defined(LITTLE_FOOT_PRINT)

#define TFT_BL 2
static const uint16_t screenWidth  = 800;
static const uint16_t screenHeight = 480;
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[ screenWidth * screenHeight / 10 ];

/* 
 * Touch support ( added by Proteus )
 */
#include "TAMC_GT911.h"



TAMC_GT911 Touch = TAMC_GT911(TOUCH_SDA, TOUCH_SCL, TOUCH_INT, TOUCH_RST, TOUCH_WIDTH, TOUCH_HEIGHT);

/*End Touch support */

Arduino_ESP32RGBPanel *bus = new Arduino_ESP32RGBPanel(
    GFX_NOT_DEFINED /* CS */, GFX_NOT_DEFINED /* SCK */, GFX_NOT_DEFINED /* SDA */,
    41 /* DE */, 40 /* VSYNC */, 39 /* HSYNC */, 42 /* PCLK */,
    14 /* R0 */, 21 /* R1 */, 47 /* R2 */, 48 /* R3 */, 45 /* R4 */,
    9 /* G0 */, 46 /* G1 */, 3 /* G2 */, 8 /* G3 */, 16 /* G4 */, 1 /* G5 */,
    15 /* B0 */, 7 /* B1 */, 6 /* B2 */, 5 /* B3 */, 4 /* B4 */
);
Arduino_RPi_DPI_RGBPanel *Screen = new Arduino_RPi_DPI_RGBPanel(
  bus,
  800 /* width */, 0 /* hsync_polarity */, 210 /* hsync_front_porch */, 30 /* hsync_pulse_width */, 16 /* hsync_back_porch */,
  480 /* height */, 0 /* vsync_polarity */, 22 /* vsync_front_porch */, 13 /* vsync_pulse_width */, 10 /* vsync_back_porch */,
  1 /* pclk_active_neg */, 16000000 /* prefer_speed */, true /* auto_flush */);

/* Display flushing */
void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
   uint32_t w = (area->x2 - area->x1 + 1);
   uint32_t h = (area->y2 - area->y1 + 1);

#if (LV_COLOR_16_SWAP != 0)
   Screen->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
   Screen->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif

   lv_disp_flush_ready(disp);
}

/*Read the touchpad*/
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data)
{
  if (Touch.touch_has_signal())
  {
    if (Touch.touch_touched())
    {
      data->state = LV_INDEV_STATE_PR;
      data->point.x = Touch.touch_last_x;
      data->point.y = Touch.touch_last_y;
    }
    else if (Touch.touch_released())
    {
      data->state = LV_INDEV_STATE_REL;
    }
  }
  else
  {
    data->state = LV_INDEV_STATE_REL;
  }
}

void lvgl_task( void * pvParameters )
{
  // while(1){
  // lv_timer_handler(); /* let the GUI do its work */
  // vTaskDelay(5);
  // }
}



/**
 * Inicjalizacja ekranu oraz dotyku.
 *
 * @param screenON Czy ekran ma być włączony przy starcie.
 * @param backlight jasność podświetlenia 0-255.
 * 
 * @note inicjalizuje obiekty [Screen] [Touch] orav [LVGL]
 */
void BoardInit(bool screenON,uint8_t bakcligth){


  Screen->begin();
  Screen->displayOff();
  if (screenON) {
  Screen->displayOn();
  Screen->setBackLight(bakcligth);
  }
  
  Touch.begin();
  Touch.setRotation(1);
  Serial.begin(115200);

  lv_init();
  lv_disp_draw_buf_init( &draw_buf, buf, NULL, screenWidth * screenHeight / 10 );
  /*Initialize the display*/
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init( &disp_drv );
  /*Change the following line to your display resolution*/
  disp_drv.hor_res = screenWidth;
  disp_drv.ver_res = screenHeight;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register( &disp_drv );
  /*Initialize the (dummy) input device driver*/
  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init( &indev_drv );
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register( &indev_drv );

  ui_init();

  // xTaskCreatePinnedToCore(lvgl_task,"lvgl_task",10000,NULL,0,NULL,0);
}








#endif // _ARDUINO_GFX_LIBRARIES_H_
